<?php
/// EJERCICIO-2 ///
/// CARLOS ALBERTO MEJIA BARAHONA ///
/// MB01132820 ///

//Asignamos las variables
$Dado1=0;
$Dado2=0;
	print_r("Serie de combinaciones posibles");
// Hacemos el conteo de los numeros del uno al seis y se los asignamos a $Dado1	
for ($Dado1 = 1; $Dado1 < 7; $Dado1++) {
	$CombinacionesDado1=$Dado1;
	// Hacemos el conteo de los numeros del uno al seis y se los asignamos a $Dado2
    for ($Dado2 = 1; $Dado2 < 7; $Dado2++) {
		// Mostramos el conteo de los dos lazamientos y los concatenamos para formar las combinaciones.
		echo "\n";  
        echo "[$Dado1,$Dado2]";

    }
    $CombinacionesDado2=$Dado2;
 }
 //A la variable $resultado le asignamos el valor de las dos varibles, $Dado1 y $Dado2. 
 $resultado=($CombinacionesDado1*$CombinacionesDado2)-(6);
 echo"\n..........................................";
 // Mostramos el resultado de la operacion para calcular las combinaciones posibles.
 print_r("\nEl numero de combinaciones posibles es: ".$resultado);

?>

