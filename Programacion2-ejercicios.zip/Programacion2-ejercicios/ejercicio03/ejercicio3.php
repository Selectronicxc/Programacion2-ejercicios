<?php
/// EJERCICIO-3 ///
/// CARLOS ALBERTO MEJIA BARAHONA ///
/// MB01132820 ///

// Creamos la clase pedirradio
class pedirRadio
{
	// creamos la funcion readline
    function readline()
    {
		//Retornamos a la line del Promt y esperamos el ingreso de datos
        return rtrim(fgets(STDIN));
        
    }
    
}

$Dato = new pedirRadio();
echo "Favor ingrese el radio de un circulo ","\n";
$rIngresado = "Ingrese el valor del radio: ";
echo $rIngresado;
// capturamos el dato ingresado por el usuario y se lo asignamos a la variable $rIngresado
$rIngresado = $Dato->readline();
$rIngresado = (float)$rIngresado;
// Hacemos la operacion y se la asignamos a la variable $Perimetro
$Perimetro=2*pi()*($rIngresado);
// La variable $Area contine la funcion pi y lo elevamos al radio ingresado
$Area=pi()*pow($rIngresado,2);

echo"****************************************","\n";
echo "El valor del perimetro es: ".$Perimetro,"\n";
echo "El valor del Area es: ".$Area, "\n";
echo"****************************************","\n";



?>
