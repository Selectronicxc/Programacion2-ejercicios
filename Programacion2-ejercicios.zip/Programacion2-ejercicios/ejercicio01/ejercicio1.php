<?php
/// EJERCICIO-1 ///
/// CARLOS ALBERTO MEJIA BARAHONA ///
/// MB01132820 ///
class pedirNumero
{
	// creamos la funcion readline
    function readline()
    {
		//Retornamos a la line del Promt y esperamos el ingreso de datos
        return rtrim(fgets(STDIN));
        
    }
}


$Dato = new pedirNumero();
echo "Favor ingrese solo numero entero de tres digitos","\n";
$nIngresado = "Ingrese numero: ";
echo $nIngresado;
$nIngresado = $Dato->readline();
$nIngresado = (string)$nIngresado;
$resultado="";
	//Se realiza el bucle for, recorriendo la cadena desde el final hasta el inicio
	for ($i=strlen($nIngresado);$i>=0;$i--)
	{
		//Se añaden los valores a la variable resultado 
		$resultado.= $nIngresado[$i];
		}
echo "El resultado es: " .(string)$resultado;
//echo $invertirNumero;


?>
