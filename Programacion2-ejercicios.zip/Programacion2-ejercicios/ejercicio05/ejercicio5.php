<?php
/// EJERCICIO-5 ///
/// CARLOS ALBERTO MEJIA BARAHONA ///
/// MB01132820 ///

class SumaRusa{

	// creamos la funcion readline
    function readline()
    {
		//Retornamos a la line del Promt y esperamos el ingreso de datos
        return rtrim(fgets(STDIN));
        
    }   
}

$Dato1 = new SumaRusa($nMultiplicador);
$Dato2 = new SumaRusa($nMultiplicando);
echo "Favor ingrese los siguientes datos ","\n";
echo"\n";
// A la variable nMultiplicador asignamos el numero ingresado 	
$nMultiplicador = $Dato1->readline(print "Ingrese un multiplicador: ");
// A la variable nMultiplicando asignamos el numero ingresado por el usuario que esta contenido en Dato2
$nMultiplicando = $Dato2->readline(print "Ingrese un multiplicando: ");
$Resultado=0;

// formamos la condicion mientras que el Multiplicador sea mayor o igual que 1 hara el siguiente ciclo 
while($nMultiplicador>=1){
	
	// Si el multiplicador es divisible por 2 y su residuo es 1, asignamos a la variable resultado, luego dividimod y multiplicamos por 2 a cada numero ingresado
	if ($nMultiplicador%2==1) {
		$Resultado=$Resultado+$nMultiplicando;
		
	}
	$nMultiplicador=$nMultiplicador/2;
	$nMultiplicando=$nMultiplicando*2;
	
	}

echo"\n";			
echo"****************************************","\n";
echo "El resultado es: ".$Resultado, "\n";
echo"****************************************","\n";

?>
