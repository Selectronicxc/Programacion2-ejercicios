<?php
/// EJERCICIO-4 ///
/// CARLOS ALBERTO MEJIA BARAHONA ///
/// MB01132820 ///

// Creamos la Clase principal para luego llamar a las demas
class ValorPi
{
	// creamos la funcion readline
    function readline()
    {
		//Retornamos a la line del Promt y esperamos el ingreso de datos
        return rtrim(fgets(STDIN));
        
    }
    //function pi()
    
}

$Dato = new ValorPi($nIngresado);
echo "Favor ingrese un número entero ","\n";
$nIngresado = "El número es: ";
echo $nIngresado;
$nIngresado = $Dato->readline();
$nIngresado = (int)$nIngresado; //Se convierte el número a entero si el usuario ingresó un decimal
$suma=0;
$contador=0;

// recorremos la funcion hasta el valor de nIngresado y se asignamos a la variable contador incrementando
for ($contador = 0; $contador <= $nIngresado; $contador++) {
	// La variable $resultado contiene la funcion de la suma infinta para calcular el valor de pi
    $resultado=4*(pow(-1,$contador)/(2*($contador)+1));
    $suma=$suma+$resultado;
}

echo"****************************************","\n";
echo "N: ".$nIngresado," Devuelve ", $suma,"\n";
echo"****************************************","\n";



?>
